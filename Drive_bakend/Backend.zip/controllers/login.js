import LoginModel from "../models/login.js"

const httpLogin = {
    getLogins: async ( req, res ) => {
        try {
            const logins = await LoginModel.find({}) 
            res.json({ logins })
        } catch (error) {
            res.status(500).json({ mensaje: "Error al obtener los ", error })
        }
    },

    postLogin: async ( req, res ) => {
        const { password, usuario, paciente, administrativo, doctor } = req.body;
        const login = new LoginModel({
            password,
            usuario,
            administrativo,
            paciente,
            doctor
        });

        try {
            const nuevoLogin = await login.save();
            res.json({
                mensaje: "Un login insertado!!",
                nuevoLogin
            })
        } catch (error) {
            res.status(500).json({ mensaje: "Error al insertar el login", error })
        }
    },

    putLogin: async ( req, res ) => {
        const { cedula } = req.params;
        const { password, usuario, paciente, administrativo, doctor } = req.body;
        const login = await LoginModel.findByIdAndUpdate( cedula, { password, usuario, paciente, administrativo, doctor }, { new: true } )
        res.json({
            mensaje: "Datos actualizados exitosamente",
            login
        })
    }
}

export default httpLogin
