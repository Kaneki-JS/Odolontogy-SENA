import PersonalModel from "../models/personal_clinico.js"
import bcryptjs from "bcryptjs"


const httpPersonal = {
    getPersonal: async (req, res) => {
        try {
            const ProgramasFormacion = await PersonalModel.find({});
            res.json({ ProgramasFormacion });
        } catch ( error ) {
            res.status(500).json({ mensaje: "Error al obtener las formaciones", error })
        }
    },

    postPersonal: async ( req, res ) => {
        const { id, denominacion, codigo, version, estado } = req.body;
        const ProgramasFormacion = new PersonalModel({
            id,
            denominacion,
            codigo,
            version,
            estado
        });

        try {
            const nuevaProgramasFormacion = await ProgramasFormacion.save();

            res.json({
                mensaje: "Una formacion insertada!!",
                nuevaProgramasFormacion
            });
        } catch (error) {
            res.status(500).json({ mensaje: "Error al insertar la formacion", error });
        }
    },

    putPersonal: async ( req, res ) => {
        const { id } = req.params;
        const { denominacion, codigo } = req.body;

        try {
            const ProgramasFormacionActualizada = await PersonalModel.findOneAndUpdate(
                { id },
                { $set: { denominacion, codigo } },
                { new: true }
            );

            if ( ProgramasFormacionActualizada ) {
                res.json({
                    mensaje: "Registro modificado exitosamente",
                    ProgramasFormacion: ProgramasFormacionActualizada
                });
            } else {
                res.json({ mensaje: "No se encontro la formacion con el id proporcionado" })
            }
        } catch (error) {
            res.status(500).json({ mensaje: "Error al actualizar la formacion", error })
        }
    },

    putPersonalEstado: async ( req, res ) => {
        const { id } = req.params;

        try {
            
            const ProgramasFormacion = await PersonalModel.findOne({id});

            if ( !ProgramasFormacion ) {
                return res.status(400).json({ mensaje: "Formacion no encontrada" });
            }

            ProgramasFormacion.estado = !ProgramasFormacion.estado

            await ProgramasFormacion.save();

            const estadoMensaje = ProgramasFormacion.estado ? "Activo" : "Inactivo";

            res.json({
                mensaje: `Estado de la formacion modificada a  ${ estadoMensaje }`,
                ProgramasFormacion
            });
        } catch (error) {
            res.status(500).json({ mensaje: "Error l cambiar el estado de la formacion", error })
        }
    }
}

export default httpPersonal