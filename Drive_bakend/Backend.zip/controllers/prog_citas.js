import CitasModel from "../models/citas.js"

const httpCitas = {
    getCitas: async (req, res) => {
        try {
            const citas = await CitasModel.find({})
            res.json({ citas })
        } catch (error) {
            res.status(500).json({ mensaje: "Error al obtener las citas", error })
        }
    },

    postCitas: async (req, res) => {
        const { paciente, dentista, fecha, hora, estado } = req.body;
        const cita = new CitasModel({
            paciente,
            dentista,
            fecha,
            hora,
            estado
        });

        try {
            const nuevaCita = await cita.save();
            res.json({
                mensaje: "Una cita insertada!!",
                nuevaCita
            })
        } catch (error) {
            res.status(500).json({ mensaje: "Error al ingresar la cita", error })
        }
    },

    putCita: async (req, res) => {
        const { cedula } = req.params;
        const { paciente, dentista, fecha, hora, estado } = req.body;
        const cita = await CitasModel.findByIdAndUpdate( cedula, { paciente, dentista, fecha, hora, estado }, { new: true } )
        res.json({
            mensaje: "Datos actualizados exitosamente",
            cita
        })
    }
}

export default httpCitas