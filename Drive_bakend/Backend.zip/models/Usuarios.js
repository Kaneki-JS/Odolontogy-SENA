import mongoose from "mongoose";

const UsuariosSchema = new mongoose.Schema({
    id: {type: String},
    nombre:{type:String},
    apellidos:{type:String},
    cedula:{type:String},
    telefono:{type:String},
    email:{type:String},
    password:{type:String},
    estado:{type: Boolean, default: true}
}) 

export default mongoose.model("Usuario", UsuariosSchema)
