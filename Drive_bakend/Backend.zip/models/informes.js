import mongoose from "mongoose";

const pacienteSchema = new mongoose.Schema({
    nombre: String,
    // Otros campos del paciente (como apellidos, cédula, etc.)
    fechaAtencion: Date,  // Campo para almacenar la fecha de atención
    dentista: { type: mongoose.Schema.Types.ObjectId, ref: 'Dentista' }  // Referencia al dentista
});

export default mongoose.model("Paciente", pacienteSchema);
