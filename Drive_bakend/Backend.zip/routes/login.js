import httpLogin from "../controllers/login.js";
import { Router } from "express";
import {check} from "express-validator"
import {validarResultados} from "../Middlewares/validaciones.js"

const router = Router()
router.get("/", httpLogin.getLogins)

router.post("/", [], httpLogin.postLogin)

router.put("/:cedula", httpLogin.putLogin)

export default router