<template>
  <div class="center">
    <img
      src="https://lostramites.com.co/wp-content/uploads/logo-de-SENA-png-Negro-300x300.png"
      id="img2"
      alt=""
    />

    <h1 class="h1">Bienvenido!!!</h1>
  </div>
</template>

<script setup>
</script>

<style scoped>
.center {
  justify-content: center;
  align-items: center;
  display: flex;
  flex-direction: column;
  height: 90vh;
}

#img2 {
  max-width: 100%; /* Aumentar el tamaño de la imagen */
  width: 30em;
  opacity: 10%;
  margin-top: 5%;
}

.h1 {
  font-family: cursive;
  font-size: 9vw;
  margin-top: -5%;
}
</style>