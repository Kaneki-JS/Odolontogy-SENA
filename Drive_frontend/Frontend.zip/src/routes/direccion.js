const urlBackend= "http://localhost:3500"

// local = "http://localhost:3500"
// render = "https://repositorio-sena.onrender.com"

export{urlBackend}